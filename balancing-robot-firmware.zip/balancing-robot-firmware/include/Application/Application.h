#ifndef APPLICATION_H
#define APPLICATION_H

#include <PIDControl_Service.h>
#include "SignalHandler_Service.h"
#include "IoHwAb_UltraSonic.h"
#include "DataHandler_Service.h"
#include "IoHwAb_HandMotion.h"

void Application_Init();

void Application_Run();

#endif // APPLICATION_H